<template>
    <v-container class="py-8" style="max-width: 900px;">
        <h1 class="text-center mb-6">Política de Privacidad</h1>

        <p style="text-align: justify;">
            En Grupo SER respetamos su privacidad y estamos comprometidos a proteger la información
            personal que usted nos proporciona. Esta Política de Privacidad describe cómo recopilamos,
            utilizamos, almacenamos y protegemos sus datos.
        </p>

        <p style="text-align: justify;">
            Utilizamos sus datos únicamente para fines operativos, comerciales y legales conforme a
            las regulaciones vigentes en la República Argentina. No compartimos información personal con
            terceros salvo obligación legal o autorización explícita del usuario.
        </p>

        <p style="text-align: justify;">
            Para consultas adicionales o solicitudes relacionadas con el manejo de datos personales,
            puede comunicarse con nuestras vías de contacto oficiales.
        </p>
    </v-container>
</template>

<script>
export default {
    name: "PoliticaPrivacidad"
};
</script>
