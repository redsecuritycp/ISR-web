    <template>
        <v-container class="py-8" style="max-width: 900px;">
            <h1 class="text-center mb-6">Términos y Condiciones</h1>

            <p style="text-align: justify;">
                Al utilizar los servicios y productos ofrecidos por Grupo SER, usted acepta los presentes
                Términos y Condiciones. Estos establecen las reglas generales, responsabilidades y limitaciones
                aplicables al uso del sitio web y servicios asociados.
            </p>

            <p style="text-align: justify;">
                La información publicada en este sitio puede estar sujeta a cambios sin previo aviso.
                Grupo SER no se responsabiliza por daños derivados del uso incorrecto o indebido de los
                servicios ofrecidos.
            </p>

            <p style="text-align: justify;">
                El acceso y utilización del sitio implican la aceptación plena de estos Términos y
                Condiciones. Si no está de acuerdo, le solicitamos que se abstenga de utilizar los servicios.
            </p>
        </v-container>
    </template>

<script>
export default {
    name: "TerminosCondiciones"
};
</script>
