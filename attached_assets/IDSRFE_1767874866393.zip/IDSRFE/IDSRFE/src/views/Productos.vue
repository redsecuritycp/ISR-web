<template>
    <div>
        <Producto></Producto>
    </div>
</template>

<script>

import Producto from "../components/Producto.vue"

export default {
    name: 'ProductosView',

    data: () => ({
    }),

    components: { Producto }

}
</script>