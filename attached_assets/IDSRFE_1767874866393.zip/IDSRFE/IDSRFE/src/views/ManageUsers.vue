<template>
    <div>
        <manageUsers />
    </div>
</template>

<script>

import manageUsers from '@/components/ManageUsers.vue';

export default {
    name: 'ManageUserView',

    components: { manageUsers }

}
</script>